package technical_interview_preparation.Interview_Preparation_2026;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InterviewPreparation2026Application {

	public static void main(String[] args) {
		SpringApplication.run(InterviewPreparation2026Application.class, args);
	}

}
