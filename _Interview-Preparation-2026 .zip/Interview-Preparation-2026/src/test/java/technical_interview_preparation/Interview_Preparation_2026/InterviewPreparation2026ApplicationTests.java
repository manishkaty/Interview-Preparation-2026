package technical_interview_preparation.Interview_Preparation_2026;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InterviewPreparation2026ApplicationTests {

	@Test
	void contextLoads() {
	}

}
